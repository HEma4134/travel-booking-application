package com.example.TravelSathi.Repository;

import com.example.TravelSathi.Entity.Stay;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StayRepository extends JpaRepository<Stay, Long> {
}